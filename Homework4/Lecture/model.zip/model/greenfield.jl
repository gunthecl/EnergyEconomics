using NamedArrays
using JuliaDB
using JuMP
using Clp
using Plots, StatPlots



demand_table = loadtable("data/demand.csv", indexcols=1)
costs_table = loadtable("data/costs.csv", indexcols=1)
availability_table = loadtable("data/availability.csv", indexcols=1)

TECHNOLOGY = Array(select(costs_table, :Technology))
NONDISP = string.(colnames(availability_table)[2:end])
DISP = setdiff(TECHNOLOGY, NONDISP)

HOUR = select(demand_table, :Hour)

demand = NamedArray(select(demand_table, :Demand),
                   (select(demand_table, :Hour), ),
                   ("Hour",))

i = 0.04
annuity = map(row-> row.OC * (i+1)^row.Lifetime / (((1+i)^row.Lifetime)-1), costs_table)

annuity = NamedArray(annuity,
                    (TECHNOLOGY,),
                    ("Technology",))

mc = NamedArray(select(costs_table, :MC),
                (TECHNOLOGY,),
                ("Technology",))



avail_arr = hcat([columns(availability_table, i) for i in 2:4]...)
avail = NamedArray(avail_arr, (HOUR,NONDISP), ("Hour","Nondisp"))

###############################################################################


function invest(res_share::Int, solver=error("Set a solver!"))

    Invest = Model(solver=solver)

    @variable(Invest, G[HOUR,TECHNOLOGY] >= 0)
    @variable(Invest, CU[HOUR,NONDISP] >= 0)
    @variable(Invest, CAP[TECHNOLOGY] >= 0)

    @objective(Invest, Min,

        sum(mc[tech] * G[hour,tech] * 8760/length(HOUR) for tech in TECHNOLOGY, hour in HOUR)

        + sum(annuity[tech] * CAP[tech] for tech in TECHNOLOGY) )

    @constraint(Invest, EnergyBalance[hour=HOUR],

        sum(G[hour,tech] for tech in TECHNOLOGY)

        ==

        demand[hour])

    @constraint(Invest, MaxGeneration[hour=HOUR, disp=DISP],

        G[hour,disp] <= CAP[disp])

    @constraint(Invest, MaxInfeed[hour=HOUR, nondisp=NONDISP],

        G[hour,nondisp] + CU[hour,nondisp]

        ==

        avail[hour,nondisp] * CAP[nondisp])

    @constraint(Invest, ResShare,

        sum(G[hour,nondisp] for hour in HOUR, nondisp in NONDISP)

        ==

        res_share/100 *
        sum(demand[hour] for  hour in HOUR) )


    status = solve(Invest)

    capacity = NamedArray(getvalue(CAP.innerArray) ./ 1000,
                         (TECHNOLOGY,),
                         ("Technology",))

    generation = NamedArray(getvalue(G.innerArray) ./ 1000000,
                           (HOUR,TECHNOLOGY),
                           ("Hour","Technology"))

    curtailment = NamedArray(getvalue(CU.innerArray) ./ 1000000,
                            (HOUR,NONDISP),
                            ("Hour","Technology"))

    return capacity, generation, curtailment
end


scenario = [80,90,100]
nr_scenario = length(scenario)
len_tech = length(TECHNOLOGY)

capacity = zeros(len_tech,nr_scenario)
generation = zeros(len_tech,nr_scenario)
curtailment = zeros(nr_scenario)


for (i,share) in enumerate(scenario)
    println("Calculating scenario with RES share $share %")
    cap, gen, cur = invest(share, ClpSolver())
    capacity[:,i] = Array(cap)
    generation[:,i] = Array(sum(gen, 1))
    curtailment[i] = sum(cur)
end



colors = [:orange :grey :blue :cyan :yellow]

groupedbar(scenario,
           capacity',
           bar_position = :stack,
           label=TECHNOLOGY,
           color=colors,
           legend=:topleft,
           title="Installed capacity for different RES shares",
           ylabel="Installed capacity in GW",
           xlabel="RES share in %")
p = twinx()
plot!(p,
    scenario,
    curtailment,
    label="Curtailment [TWh]",
    color=:red,
    legend=:left)
